"""
Calcular el nuevo salario de un obrero si obtuvo un incremento del 25% sobre su salario anterior.
"""

salario_anterior = int(input("Ingrese su salario anterior: "))

incremeto_salario = salario_anterior * 0.25
nuevo_salario = salario_anterior + incremeto_salario

print("El incremento de su salario es de: ", incremeto_salario)
print("Por ello el nuevo salario de un obrero es: ", nuevo_salario)


